# SENTINEL Attack Scenario Orchestrator

Single-command MITRE ATT&CK adversary emulation against the seeded SENTINEL-AI lab.

```
~/sentinel-attack/
├── scenario.py            # entrypoint
├── docs/
│   ├── SUPERVISOR_GUIDE.md      ← READ THIS
│   └── SUPERVISOR_GUIDE.pdf
├── lib/
│   ├── state.py           # SQLite state, MITRE technique lookup
│   ├── actor.py           # kiddie / commodity / apt profiles
│   ├── runner.py          # subprocess wrapper with audit + retry/skip prompts
│   ├── menu.py            # operator UI
│   └── acts/
│       ├── act1_recon.py
│       ├── act2_access.py
│       └── act3_postex.py
├── wordlists/
│   ├── gen_wordlist.py
│   └── targeted.txt       # generated on first run
├── scenario.db            # generated on first run
└── runs/                  # per-run logs and artifacts
```

## Quick start

```bash
# 0. (one time) ensure tools are installed
python3 scenario.py --check-tools

# 1. (one time) generate targeted wordlist
python3 wordlists/gen_wordlist.py

# 2. (every run) start
sudo python3 scenario.py --actor apt
```

Pick acts from the main menu. After completion, choose `e` from the main menu to export the evidence JSON to `~/scenario_runs/`.

## Why this exists

See `docs/SUPERVISOR_GUIDE.md` for the full design rationale, MITRE technique mapping, and supervisor-facing defense of every architectural decision.
