#!/usr/bin/env python3
"""
scenario.py — SENTINEL Attack Scenario Orchestrator (entrypoint).

Single command that drives the entire MITRE ATT&CK simulation against the
seeded lab. Run from Kali; reads the seeded scenario state from MySQL +
AD; writes attacker-side evidence to ~/scenario_runs/<run_id>/.

Usage:
    scenario.py [--actor {kiddie,commodity,apt}] [--check-tools]
                [--resume RUN_ID] [--db PATH] [--runs-dir PATH]

Examples:
    # Run with default APT actor (the most realistic scenario)
    sudo python3 scenario.py --actor apt

    # Quick smoke test with kiddie actor (loud, fast)
    sudo python3 scenario.py --actor kiddie

    # Verify the box has all the attack tools first
    python3 scenario.py --check-tools
"""

from __future__ import annotations

import argparse
import datetime
import os
import shutil
import sys
from pathlib import Path

# Make sibling `lib` importable when launching as a script
HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from lib.actor import PROFILES, get_profile                                # noqa: E402
from lib.menu import (BANNER, MAIN_MENU, export_evidence, prompt_menu,      # noqa: E402
                      render_banner, render_status_line, show_state)
from lib.runner import C, Runner, colour                                    # noqa: E402
from lib.state import StateManager                                          # noqa: E402
from lib.acts import act1_recon, act2_access, act3_postex                   # noqa: E402


REQUIRED_TOOLS = [
    "nmap", "dig", "hydra", "sqlmap", "curl", "ssh", "sshpass",
    "impacket-GetNPUsers", "impacket-GetUserSPNs", "impacket-lookupsid",
    "john", "ldapsearch", "rpcclient", "nc", "tar", "base64",
]


def check_tools() -> int:
    """Verify every external command we depend on is on PATH."""
    print(colour("\n  ═══ Tool availability check ═══", C.CYAN, C.BOLD))
    missing: list[str] = []
    for tool in REQUIRED_TOOLS:
        path = shutil.which(tool)
        if path:
            print(colour(f"    ✓ {tool:<28} {path}", C.GREEN))
        else:
            print(colour(f"    ✗ {tool:<28} NOT FOUND", C.RED, C.BOLD))
            missing.append(tool)
    print()

    if missing:
        print(colour(
            f"  Missing {len(missing)} tool(s). On Kali, install with:\n"
            f"    apt update && apt install -y {' '.join(missing)}\n"
            f"  (Note: impacket-* and john come via the kali-tools-* metapackages.)",
            C.YELLOW))
        return 1
    print(colour("  All required tools present.\n", C.GREEN, C.BOLD))
    return 0


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="SENTINEL attack scenario orchestrator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--actor", choices=sorted(PROFILES), default="apt",
                   help="adversary profile to emulate (default: apt)")
    p.add_argument("--check-tools", action="store_true",
                   help="verify required tools are installed, then exit")
    p.add_argument("--resume", metavar="RUN_ID",
                   help="continue a previous run instead of starting fresh")
    p.add_argument("--db", type=Path,
                   default=HERE / "scenario.db",
                   help="path to SQLite state DB")
    p.add_argument("--runs-dir", type=Path,
                   default=Path.home() / "scenario_runs",
                   help="where per-run log directories go")
    p.add_argument("--no-interactive", action="store_true",
                   help="don't prompt on failures (use for CI/automation)")
    return p.parse_args()


def make_run_id(actor: str) -> str:
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{ts}_{actor}"


def main() -> int:
    args = parse_args()

    if args.check_tools:
        return check_tools()

    profile = get_profile(args.actor)
    state = StateManager(db_path=args.db)

    # Resolve run id (new vs resume).
    if args.resume:
        run_id = args.resume
        existing = state.conn.execute(
            "SELECT * FROM runs WHERE run_id = ?", (run_id,)).fetchone()
        if not existing:
            print(colour(f"  (!) no such run: {run_id}", C.RED, C.BOLD))
            return 2
        if existing["actor_profile"] != args.actor:
            print(colour(
                f"  (!) run was started with actor={existing['actor_profile']} "
                f"but you passed --actor {args.actor}. "
                f"Using the original profile.",
                C.YELLOW))
            profile = get_profile(existing["actor_profile"])
        print(colour(f"  ↻ resuming run {run_id}", C.CYAN, C.BOLD))
    else:
        run_id = make_run_id(profile.name)
        state.start_run(run_id, profile.name)

    run_dir = args.runs_dir / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    runner = Runner(
        state=state, run_id=run_id, run_dir=run_dir,
        interactive=not args.no_interactive,
    )

    render_banner(profile, run_id)

    try:
        return main_loop(runner, profile, state, run_dir, args.runs_dir)
    finally:
        state.close()


def main_loop(runner, profile, state, run_dir, runs_dir_root) -> int:
    while True:
        render_status_line(state, runner.run_id)
        choice = prompt_menu("Main Menu", MAIN_MENU)
        if choice == "1":
            act1_recon.loop(runner, profile, state)
        elif choice == "2":
            act2_access.loop(runner, profile, state)
        elif choice == "3":
            act3_postex.loop(runner, profile, state)
        elif choice == "s":
            show_state(state, runner.run_id)
        elif choice == "e":
            export_evidence(state, runner.run_id, runs_dir_root)
        elif choice == "q":
            print(colour("\n  Goodbye. Run logs in: " + str(run_dir), C.BOLD))
            state.end_run(runner.run_id, "abandoned")
            return 0


if __name__ == "__main__":
    try:
        rc = main()
    except KeyboardInterrupt:
        print(colour("\n\n  Interrupted by operator. Bye.", C.YELLOW, C.BOLD))
        rc = 130
    sys.exit(rc)
