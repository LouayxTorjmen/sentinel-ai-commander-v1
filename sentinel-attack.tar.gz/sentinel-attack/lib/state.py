"""
state.py — SQLite-backed scenario state.

Persistence model:
  runs              — one row per scenario invocation
  steps             — one row per command executed
  hosts             — recon / compromise status per target
  credentials       — every credential discovered
  artifacts         — files / loot collected from victims
  mitre_techniques  — lookup table (technique_id → name, tactic, description)

Why SQLite and not JSON: the orchestrator needs to query "have we already
recon'd srv-web in this run?" or "list all creds I haven't tried yet."
That's relational reasoning. JSON would require loading + filtering Python
lists every time. SQLite lets the orchestrator reason about state in a
language designed for it.
"""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


DB_VERSION = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS runs (
    run_id        TEXT PRIMARY KEY,
    started_at    TEXT NOT NULL,
    ended_at      TEXT,
    actor_profile TEXT NOT NULL,
    status        TEXT NOT NULL,
    notes         TEXT
);

CREATE TABLE IF NOT EXISTS steps (
    step_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id         TEXT    NOT NULL REFERENCES runs(run_id),
    act            TEXT    NOT NULL,
    tactic         TEXT    NOT NULL,
    technique      TEXT    NOT NULL,
    technique_name TEXT,
    tool           TEXT,
    target_host    TEXT,
    command        TEXT,
    started_at     TEXT    NOT NULL,
    ended_at       TEXT,
    rc             INTEGER,
    log_path       TEXT,
    outcome        TEXT
);

CREATE TABLE IF NOT EXISTS hosts (
    host_id           INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id            TEXT    NOT NULL REFERENCES runs(run_id),
    hostname          TEXT,
    ip                TEXT    NOT NULL,
    os                TEXT,
    open_ports        TEXT,
    services          TEXT,
    compromise_status TEXT    NOT NULL DEFAULT 'unknown',
    shell_method      TEXT,
    notes             TEXT,
    UNIQUE(run_id, ip)
);

CREATE TABLE IF NOT EXISTS credentials (
    cred_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id        TEXT    NOT NULL REFERENCES runs(run_id),
    source        TEXT    NOT NULL,
    source_host   TEXT,
    system        TEXT,
    service       TEXT,
    username      TEXT,
    password      TEXT,
    hash_type     TEXT,
    verified      INTEGER NOT NULL DEFAULT 0,
    discovered_at TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS artifacts (
    artifact_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id        TEXT    NOT NULL REFERENCES runs(run_id),
    source_host   TEXT    NOT NULL,
    artifact_type TEXT,
    description   TEXT,
    local_path    TEXT,
    size_bytes    INTEGER,
    collected_at  TEXT    NOT NULL
);

-- Static lookup; seeded once on init.
CREATE TABLE IF NOT EXISTS mitre_techniques (
    technique   TEXT PRIMARY KEY,
    tactic      TEXT NOT NULL,
    name        TEXT NOT NULL,
    description TEXT
);

CREATE INDEX IF NOT EXISTS idx_steps_run    ON steps(run_id);
CREATE INDEX IF NOT EXISTS idx_steps_tech   ON steps(technique);
CREATE INDEX IF NOT EXISTS idx_hosts_run    ON hosts(run_id);
CREATE INDEX IF NOT EXISTS idx_creds_run    ON credentials(run_id);
CREATE INDEX IF NOT EXISTS idx_creds_verif  ON credentials(run_id, verified);
"""

MITRE_SEED = [
    # (technique, tactic, name, description)
    ("T1595.001", "Reconnaissance",        "Active Scanning: Scanning IP Blocks",
     "Adversary scans IP ranges to identify hosts and services."),
    ("T1590",     "Reconnaissance",        "Gather Victim Network Information",
     "Collects network topology data — DNS records, zone files, IP ranges."),
    ("T1592",     "Reconnaissance",        "Gather Victim Host Information",
     "Service version + OS fingerprint via banner grabbing."),
    ("T1589.002", "Reconnaissance",        "Gather Victim Identity: Email Addresses",
     "Enumerates user accounts via SMB/LDAP/RID-cycling."),
    ("T1190",     "Initial Access",        "Exploit Public-Facing Application",
     "Exploits a vulnerable internet-facing app (e.g. DVWA command injection)."),
    ("T1110.001", "Credential Access",     "Brute Force: Password Guessing",
     "Multiple password attempts against a known username on a network service."),
    ("T1078",     "Initial Access",        "Valid Accounts",
     "Uses previously-obtained credentials to authenticate to a service."),
    ("T1003.008", "Credential Access",     "OS Credential Dumping: /etc/passwd and /etc/shadow",
     "Reads local password hashes from a compromised host."),
    ("T1558.004", "Credential Access",     "Steal or Forge Kerberos Tickets: AS-REP Roasting",
     "Requests AS-REP for accounts with DoesNotRequirePreAuth, cracks offline."),
    ("T1558.003", "Credential Access",     "Steal or Forge Kerberos Tickets: Kerberoasting",
     "Requests service tickets for SPN-registered accounts, cracks offline."),
    ("T1110.002", "Credential Access",     "Brute Force: Password Cracking",
     "Offline cracking of recovered hashes against a wordlist."),
    ("T1083",     "Discovery",             "File and Directory Discovery",
     "Lists files, looks for SUID binaries, finds config files with secrets."),
    ("T1018",     "Discovery",             "Remote System Discovery",
     "Identifies other hosts reachable from the compromised position."),
    ("T1021.004", "Lateral Movement",      "Remote Services: SSH",
     "Authenticates to another host using discovered credentials over SSH."),
    ("T1041",     "Exfiltration",          "Exfiltration Over C2 Channel",
     "Transmits collected data back to attacker-controlled infrastructure."),
    ("T1486",     "Impact",                "Data Encrypted for Impact",
     "Symbolic impact action; we drop a 'ransom note' file, no actual encryption."),
    ("T1059.004", "Execution",             "Command and Scripting Interpreter: Unix Shell",
     "Shell commands executed on a compromised Unix host via webshell or SSH."),
]


def now_utc() -> str:
    """ISO-8601 UTC timestamp with Z suffix. Used everywhere."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


@dataclass
class StateManager:
    """Thin wrapper around sqlite3 with helpers for the orchestrator's domain."""
    db_path: Path
    conn: sqlite3.Connection = field(init=False)

    def __post_init__(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(
            self.db_path,
            isolation_level=None,         # autocommit
            detect_types=sqlite3.PARSE_DECLTYPES,
        )
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON;")
        self.conn.executescript(SCHEMA)
        self._seed_mitre()
        self._seed_meta()

    # ─── Bootstrap ────────────────────────────────────────────────

    def _seed_mitre(self) -> None:
        for tech, tactic, name, desc in MITRE_SEED:
            self.conn.execute(
                "INSERT OR IGNORE INTO mitre_techniques (technique, tactic, name, description) "
                "VALUES (?, ?, ?, ?)",
                (tech, tactic, name, desc),
            )

    def _seed_meta(self) -> None:
        self.conn.execute(
            "INSERT OR IGNORE INTO meta (key, value) VALUES ('db_version', ?)",
            (str(DB_VERSION),),
        )

    # ─── Run lifecycle ────────────────────────────────────────────

    def start_run(self, run_id: str, actor_profile: str, notes: str = "") -> None:
        self.conn.execute(
            "INSERT INTO runs (run_id, started_at, actor_profile, status, notes) "
            "VALUES (?, ?, ?, 'running', ?)",
            (run_id, now_utc(), actor_profile, notes),
        )

    def end_run(self, run_id: str, status: str) -> None:
        self.conn.execute(
            "UPDATE runs SET ended_at = ?, status = ? WHERE run_id = ?",
            (now_utc(), status, run_id),
        )

    def latest_running_run(self) -> sqlite3.Row | None:
        """Used to detect 'do you want to resume a previous run?'"""
        return self.conn.execute(
            "SELECT * FROM runs WHERE status = 'running' "
            "ORDER BY started_at DESC LIMIT 1"
        ).fetchone()

    # ─── Steps ────────────────────────────────────────────────────

    def begin_step(
        self,
        run_id: str,
        act: str,
        technique: str,
        tool: str,
        command: str,
        target_host: str | None = None,
    ) -> int:
        """Insert a step row, return its step_id. Caller calls end_step() after the command runs."""
        tech_row = self.conn.execute(
            "SELECT tactic, name FROM mitre_techniques WHERE technique = ?",
            (technique,),
        ).fetchone()
        tactic = tech_row["tactic"] if tech_row else "Unknown"
        tech_name = tech_row["name"] if tech_row else technique
        cur = self.conn.execute(
            "INSERT INTO steps "
            "(run_id, act, tactic, technique, technique_name, tool, target_host, "
            " command, started_at, outcome) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'running')",
            (run_id, act, tactic, technique, tech_name, tool, target_host,
             command, now_utc()),
        )
        return cur.lastrowid

    def end_step(self, step_id: int, rc: int, outcome: str, log_path: str | None = None) -> None:
        self.conn.execute(
            "UPDATE steps SET ended_at = ?, rc = ?, outcome = ?, log_path = ? "
            "WHERE step_id = ?",
            (now_utc(), rc, outcome, log_path, step_id),
        )

    def steps_for_run(self, run_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM steps WHERE run_id = ? ORDER BY started_at",
            (run_id,),
        ).fetchall()

    def step_count_by_outcome(self, run_id: str) -> dict[str, int]:
        rows = self.conn.execute(
            "SELECT outcome, COUNT(*) AS n FROM steps WHERE run_id = ? GROUP BY outcome",
            (run_id,),
        ).fetchall()
        return {r["outcome"]: r["n"] for r in rows}

    # ─── Hosts ────────────────────────────────────────────────────

    def upsert_host(
        self,
        run_id: str,
        ip: str,
        hostname: str | None = None,
        os: str | None = None,
        open_ports: list[int] | None = None,
        services: dict[str, Any] | None = None,
        compromise_status: str = "recon_only",
        shell_method: str | None = None,
        notes: str = "",
    ) -> None:
        """Insert or update a host row. Idempotent."""
        existing = self.conn.execute(
            "SELECT host_id FROM hosts WHERE run_id = ? AND ip = ?",
            (run_id, ip),
        ).fetchone()
        ports_json = json.dumps(sorted(set(open_ports))) if open_ports else None
        svcs_json = json.dumps(services) if services else None
        if existing:
            self.conn.execute(
                "UPDATE hosts SET hostname=COALESCE(?, hostname), os=COALESCE(?, os), "
                "open_ports=COALESCE(?, open_ports), services=COALESCE(?, services), "
                "compromise_status=?, shell_method=COALESCE(?, shell_method), "
                "notes=COALESCE(NULLIF(?, ''), notes) "
                "WHERE host_id = ?",
                (hostname, os, ports_json, svcs_json, compromise_status,
                 shell_method, notes, existing["host_id"]),
            )
        else:
            self.conn.execute(
                "INSERT INTO hosts "
                "(run_id, hostname, ip, os, open_ports, services, "
                " compromise_status, shell_method, notes) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (run_id, hostname, ip, os, ports_json, svcs_json,
                 compromise_status, shell_method, notes),
            )

    def hosts_for_run(self, run_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM hosts WHERE run_id = ? ORDER BY ip",
            (run_id,),
        ).fetchall()

    def compromised_hosts(self, run_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM hosts WHERE run_id = ? AND compromise_status = 'pwned' "
            "ORDER BY ip",
            (run_id,),
        ).fetchall()

    # ─── Credentials ──────────────────────────────────────────────

    def add_credential(
        self,
        run_id: str,
        source: str,
        username: str,
        password: str | None,
        system: str | None = None,
        service: str | None = None,
        source_host: str | None = None,
        hash_type: str | None = None,
        verified: int = 0,
    ) -> int:
        cur = self.conn.execute(
            "INSERT INTO credentials "
            "(run_id, source, source_host, system, service, username, password, "
            " hash_type, verified, discovered_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (run_id, source, source_host, system, service, username, password,
             hash_type, verified, now_utc()),
        )
        return cur.lastrowid

    def mark_credential_verified(self, cred_id: int, verified: int) -> None:
        """verified: 1 = confirmed working, -1 = confirmed bad"""
        self.conn.execute(
            "UPDATE credentials SET verified = ? WHERE cred_id = ?",
            (verified, cred_id),
        )

    def credentials_for_run(self, run_id: str, verified: int | None = None) -> list[sqlite3.Row]:
        if verified is None:
            return self.conn.execute(
                "SELECT * FROM credentials WHERE run_id = ? "
                "ORDER BY discovered_at",
                (run_id,),
            ).fetchall()
        return self.conn.execute(
            "SELECT * FROM credentials WHERE run_id = ? AND verified = ? "
            "ORDER BY discovered_at",
            (run_id, verified),
        ).fetchall()

    def find_credential(
        self,
        run_id: str,
        username: str,
        system: str | None = None,
    ) -> sqlite3.Row | None:
        if system:
            return self.conn.execute(
                "SELECT * FROM credentials WHERE run_id = ? AND username = ? AND system = ? "
                "ORDER BY verified DESC, discovered_at DESC LIMIT 1",
                (run_id, username, system),
            ).fetchone()
        return self.conn.execute(
            "SELECT * FROM credentials WHERE run_id = ? AND username = ? "
            "ORDER BY verified DESC, discovered_at DESC LIMIT 1",
            (run_id, username),
        ).fetchone()

    # ─── Artifacts ────────────────────────────────────────────────

    def add_artifact(
        self,
        run_id: str,
        source_host: str,
        artifact_type: str,
        description: str,
        local_path: str,
        size_bytes: int = 0,
    ) -> int:
        cur = self.conn.execute(
            "INSERT INTO artifacts "
            "(run_id, source_host, artifact_type, description, local_path, "
            " size_bytes, collected_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (run_id, source_host, artifact_type, description, local_path,
             size_bytes, now_utc()),
        )
        return cur.lastrowid

    def artifacts_for_run(self, run_id: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM artifacts WHERE run_id = ? ORDER BY collected_at",
            (run_id,),
        ).fetchall()

    # ─── Summary helpers ──────────────────────────────────────────

    def summary(self, run_id: str) -> dict[str, Any]:
        outcomes = self.step_count_by_outcome(run_id)
        return {
            "run_id": run_id,
            "hosts_recon":      len(self.hosts_for_run(run_id)),
            "hosts_compromised": len(self.compromised_hosts(run_id)),
            "credentials":      len(self.credentials_for_run(run_id)),
            "creds_verified":   len(self.credentials_for_run(run_id, verified=1)),
            "artifacts":        len(self.artifacts_for_run(run_id)),
            "step_outcomes":    outcomes,
        }

    def export_evidence(self, run_id: str) -> dict[str, Any]:
        """Generate the timestamp-aligned evidence dump used to correlate with Wazuh."""
        run_row = self.conn.execute(
            "SELECT * FROM runs WHERE run_id = ?", (run_id,)
        ).fetchone()
        if not run_row:
            return {}
        return {
            "run": dict(run_row),
            "steps":       [dict(r) for r in self.steps_for_run(run_id)],
            "hosts":       [dict(r) for r in self.hosts_for_run(run_id)],
            "credentials": [
                # redact password from export — present at run time, not in evidence file
                {**dict(r), "password": "***REDACTED***" if r["password"] else None}
                for r in self.credentials_for_run(run_id)
            ],
            "artifacts":   [dict(r) for r in self.artifacts_for_run(run_id)],
            "summary":     self.summary(run_id),
        }

    def close(self) -> None:
        self.conn.close()
