"""
runner.py — Execute external commands with full audit trail.

Every shell command the orchestrator runs goes through Runner.run(). It:

  1. Records a 'steps' row in the SQLite state (technique, command, timings).
  2. Streams stdout+stderr to a per-step .log file under runs/<run_id>/.
  3. Mirrors output to the operator's screen so the scenario feels live.
  4. Updates the step row with rc + outcome on completion.
  5. On non-zero exit, returns control to the operator with the interactive
     retry/skip/inspect/quit menu specified in design Decision 5.

Why this matters for the thesis: every attacker action has a corresponding
row in the SQLite DB with a timestamp window. The defender side (Wazuh
correlator) joins those windows against the alerts table to prove
"alert A was caused by my step B." Without this rigorous tracking the
evidence chapter is just hand-waving.
"""

from __future__ import annotations

import shlex
import signal
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Iterable, Optional

from .state import StateManager


# ─── ANSI colour helpers ────────────────────────────────────────────

class C:
    RESET = "\033[0m";   BOLD = "\033[1m";    DIM = "\033[2m"
    RED   = "\033[31m";  GREEN = "\033[32m";  YELLOW = "\033[33m"
    BLUE  = "\033[34m";  MAGENTA = "\033[35m"; CYAN  = "\033[36m"


def colour(s: str, *codes: str) -> str:
    return "".join(codes) + s + C.RESET


# ─── Outcome enum ───────────────────────────────────────────────────

class Outcome(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    SKIPPED = "skipped"
    PARTIAL = "partial"


# ─── Interactive failure decisions ──────────────────────────────────

class FailureDecision(str, Enum):
    RETRY    = "retry"
    SKIP     = "skip"
    BACK     = "back"      # back to act menu
    INSPECT  = "inspect"   # open log
    QUIT     = "quit"


def _ask_failure_decision(log_path: Path | None) -> FailureDecision:
    """
    Decision 5 interactive prompt: retry / skip / back / inspect / quit.
    Implemented as a loop because 'inspect' falls back to re-prompting.
    """
    while True:
        sys.stdout.write(colour(
            "\n    What now?\n"
            "      (r) retry this step\n"
            "      (s) skip and continue\n"
            "      (b) back to act menu\n"
            "      (i) inspect log file\n"
            "      (q) quit scenario\n"
            "    > ", C.YELLOW))
        sys.stdout.flush()
        ch = input().strip().lower()
        if ch in ("r", "retry"):    return FailureDecision.RETRY
        if ch in ("s", "skip"):     return FailureDecision.SKIP
        if ch in ("b", "back"):     return FailureDecision.BACK
        if ch in ("q", "quit"):     return FailureDecision.QUIT
        if ch in ("i", "inspect"):
            if log_path and log_path.is_file():
                print(colour(f"\n--- {log_path} ---", C.DIM))
                try:
                    print(log_path.read_text(errors="replace"))
                except Exception as e:
                    print(colour(f"(could not read: {e})", C.RED))
                print(colour(f"--- end {log_path} ---\n", C.DIM))
            else:
                print(colour("(no log file available)", C.RED))
            continue
        print(colour("    invalid choice, try again", C.RED))


# ─── StepResult ─────────────────────────────────────────────────────

@dataclass
class StepResult:
    step_id:   int
    outcome:   Outcome
    rc:        int
    stdout:    str
    log_path:  Path
    decision:  Optional[FailureDecision] = None   # set only on failure path


# ─── Runner ─────────────────────────────────────────────────────────

class Runner:
    """
    Executes commands within the context of one scenario run.

    Construct once per run with the SQLite state manager + run id +
    on-disk run directory; then call .run(...) for each step.
    """

    def __init__(
        self,
        state: StateManager,
        run_id: str,
        run_dir: Path,
        interactive: bool = True,
    ) -> None:
        self.state = state
        self.run_id = run_id
        self.run_dir = run_dir
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.interactive = interactive

    # ─── Public API ─────────────────────────────────────────────

    def run(
        self,
        *,
        act: str,
        technique: str,
        tool: str,
        argv: list[str] | str,
        target_host: str | None = None,
        timeout: int | None = 600,
        env: dict[str, str] | None = None,
        success_when_rc_in: Iterable[int] = (0,),
        treat_rc_as_partial: Iterable[int] = (),
        show_command: bool = True,
        stdin_data: bytes | None = None,
    ) -> StepResult:
        """
        Run a single command, record it, return a StepResult.

        success_when_rc_in / treat_rc_as_partial give callers a way to
        deal with tools that return non-zero on benign conditions
        (sqlmap returns 1 on 'no injection found', nmap returns 1 if
        any host is down, etc.). Callers should pick rc behavior
        carefully so we don't pop interactive prompts for benign cases.
        """

        # Normalize argv to a string for storage; build list for subprocess.
        if isinstance(argv, str):
            display_cmd = argv
            popen_args = argv
            use_shell = True
        else:
            display_cmd = " ".join(shlex.quote(a) for a in argv)
            popen_args = argv
            use_shell = False

        # Stable log filename: <step_id_placeholder>_<tech>_<tool>_<host>.log
        # We can't know step_id yet because we haven't inserted; we
        # insert first, then know the id, then write the file.

        step_id = self.state.begin_step(
            run_id=self.run_id, act=act, technique=technique,
            tool=tool, command=display_cmd, target_host=target_host,
        )

        safe_target = (target_host or "any").replace("/", "_").replace(":", "_")
        log_path = self.run_dir / f"{step_id:04d}_{technique}_{tool}_{safe_target}.log"

        if show_command:
            self._print_step_header(step_id, technique, tool, target_host, display_cmd)

        # ─── Execute ─────────────────────────────────────────
        rc, stdout_buf = self._spawn_and_capture(
            popen_args=popen_args,
            use_shell=use_shell,
            log_path=log_path,
            timeout=timeout,
            env=env,
            stdin_data=stdin_data,
        )

        # ─── Classify outcome ────────────────────────────────
        if rc in tuple(success_when_rc_in):
            outcome = Outcome.SUCCESS
        elif rc in tuple(treat_rc_as_partial):
            outcome = Outcome.PARTIAL
        elif rc == -signal.SIGTERM.value:
            outcome = Outcome.FAILURE
        else:
            outcome = Outcome.FAILURE

        self.state.end_step(step_id, rc=rc, outcome=outcome.value,
                            log_path=str(log_path.relative_to(self.run_dir)))

        # ─── Operator-facing summary ─────────────────────────
        self._print_step_footer(outcome, rc, log_path)

        result = StepResult(step_id=step_id, outcome=outcome, rc=rc,
                            stdout=stdout_buf, log_path=log_path)

        if outcome is Outcome.FAILURE and self.interactive:
            decision = _ask_failure_decision(log_path)
            result.decision = decision

        return result

    # ─── Internal helpers ───────────────────────────────────────

    def _print_step_header(
        self, step_id: int, technique: str, tool: str,
        target_host: str | None, command: str,
    ) -> None:
        target = target_host or "—"
        print()
        print(colour(f"┌─ [{step_id:04d}] {technique}  {tool}  →  {target}",
                     C.BOLD, C.CYAN))
        # Truncate very long commands at 200 chars for the screen banner;
        # the full command is in the DB step row.
        cmd_display = command if len(command) <= 200 else command[:197] + "..."
        print(colour(f"│  $ {cmd_display}", C.DIM))
        print(colour("│", C.DIM))

    def _print_step_footer(self, outcome: Outcome, rc: int, log_path: Path) -> None:
        symbols = {
            Outcome.SUCCESS: (C.GREEN,  "✓"),
            Outcome.PARTIAL: (C.YELLOW, "~"),
            Outcome.SKIPPED: (C.DIM,    "·"),
            Outcome.FAILURE: (C.RED,    "✗"),
        }
        clr, sym = symbols[outcome]
        print(colour(f"└─ {sym} {outcome.value}  rc={rc}  log={log_path.name}",
                     clr, C.BOLD))

    def _spawn_and_capture(
        self,
        popen_args,
        use_shell: bool,
        log_path: Path,
        timeout: int | None,
        env: dict[str, str] | None,
        stdin_data: bytes | None,
    ) -> tuple[int, str]:
        """
        Run the command, streaming stdout+stderr both to console and to log.
        Returns (rc, captured_stdout_str).
        """
        chunks: list[str] = []
        log_path.parent.mkdir(parents=True, exist_ok=True)

        # Open log file with header
        with log_path.open("w", encoding="utf-8") as fh:
            fh.write(f"# command: {popen_args}\n")
            fh.write(f"# started: {datetime.now(timezone.utc).isoformat()}\n")
            fh.write(f"# pid:     (about to spawn)\n\n")

            try:
                proc = subprocess.Popen(
                    popen_args,
                    shell=use_shell,
                    stdin=subprocess.PIPE if stdin_data else subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    bufsize=1,
                    text=True,
                    env=env,
                )
            except FileNotFoundError as e:
                msg = f"[FATAL] tool not found: {e}\n"
                print(colour(msg, C.RED), end="")
                fh.write(msg)
                return 127, msg

            if stdin_data is not None and proc.stdin is not None:
                try:
                    proc.stdin.write(stdin_data.decode("utf-8", errors="replace"))
                    proc.stdin.close()
                except Exception:
                    pass

            try:
                assert proc.stdout is not None
                for line in proc.stdout:
                    sys.stdout.write(colour("│  ", C.DIM) + line)
                    sys.stdout.flush()
                    fh.write(line)
                    fh.flush()
                    chunks.append(line)
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                msg = f"\n[TIMEOUT] command exceeded {timeout}s\n"
                print(colour(msg, C.RED), end="")
                fh.write(msg)
                return 124, "".join(chunks) + msg
            except KeyboardInterrupt:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                msg = "\n[INTERRUPTED] operator pressed Ctrl+C\n"
                print(colour(msg, C.YELLOW), end="")
                fh.write(msg)
                return 130, "".join(chunks) + msg

            rc = proc.returncode
            fh.write(f"\n# rc:      {rc}\n# ended:   {datetime.now(timezone.utc).isoformat()}\n")
            return rc, "".join(chunks)


# ─── Helper used by acts to register a skipped step ────────────────

def record_skip(
    state: StateManager,
    run_id: str,
    act: str,
    technique: str,
    tool: str,
    reason: str,
    target_host: str | None = None,
) -> int:
    """Record a step that we deliberately did NOT execute (e.g. precondition unmet)."""
    step_id = state.begin_step(
        run_id=run_id, act=act, technique=technique, tool=tool,
        command=f"# skipped: {reason}", target_host=target_host,
    )
    state.end_step(step_id, rc=0, outcome=Outcome.SKIPPED.value, log_path=None)
    return step_id
