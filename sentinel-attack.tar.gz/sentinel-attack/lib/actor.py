"""
actor.py — Actor profile defines HOW the same techniques get executed.

Three profiles model three rungs of adversary maturity:

  kiddie     — point-and-click attacker, default tool settings, no OPSEC.
               Loud scans, default user-agents, fast brute force, no cleanup.
               Designed to MAXIMIZE alerts. Useful for testing whether your
               baseline detection catches the easy stuff.

  commodity  — competent attacker using known tooling (e.g. commodity
               malware operator). Some OPSEC: spoofed UAs, moderate pacing,
               post-exploit log clearing. Mid-tier detection challenge.

  apt        — long-dwell threat actor. Slow scans, randomized timing,
               legitimate-looking traffic patterns, careful command choices.
               Tests whether detection holds up against patient adversaries.

The profile object exposes both KNOBS (numbers/strings tool builders read)
and BEHAVIORS (small helpers that wrap delays, logging, cleanup).
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass


@dataclass(frozen=True)
class ActorProfile:
    name: str
    description: str

    # nmap timing template (-T0..T5) and rate cap
    nmap_timing: str
    nmap_max_rate: int           # 0 = no cap

    # hydra brute-force concurrency
    hydra_threads: int
    hydra_wait_per_try: int      # seconds between tries inside one task

    # delay between top-level orchestrator steps
    inter_step_delay_min: float
    inter_step_delay_max: float

    # user-agent + curl flags
    user_agent: str
    curl_extra_flags: list[str]

    # cleanup behavior
    clear_bash_history: bool
    clear_auth_logs: bool

    # exfil method
    exfil_method: str            # 'http_post' | 'http_post_b64' | 'dns_chunks'


KIDDIE = ActorProfile(
    name="kiddie",
    description="Script kiddie. Default tools, no OPSEC, loud.",
    nmap_timing="-T4",
    nmap_max_rate=0,
    hydra_threads=16,
    hydra_wait_per_try=0,
    inter_step_delay_min=0.0,
    inter_step_delay_max=0.0,
    user_agent="Mozilla/5.0 (compatible; Nmap Scripting Engine)",
    curl_extra_flags=[],
    clear_bash_history=False,
    clear_auth_logs=False,
    exfil_method="http_post",
)

COMMODITY = ActorProfile(
    name="commodity",
    description="Commodity malware operator. Mid-tier tooling, light OPSEC.",
    nmap_timing="-T3",
    nmap_max_rate=100,
    hydra_threads=4,
    hydra_wait_per_try=1,
    inter_step_delay_min=2.0,
    inter_step_delay_max=5.0,
    user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
               "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    curl_extra_flags=["--compressed"],
    clear_bash_history=True,
    clear_auth_logs=False,
    exfil_method="http_post_b64",
)

APT = ActorProfile(
    name="apt",
    description="Patient threat actor. Slow, careful, legitimate-looking.",
    nmap_timing="-T1",
    nmap_max_rate=5,
    hydra_threads=1,
    hydra_wait_per_try=3,
    inter_step_delay_min=15.0,
    inter_step_delay_max=60.0,
    user_agent="Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
    curl_extra_flags=[
        "--compressed",
        "-H", "Accept-Language: en-US,en;q=0.5",
        "-H", "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ],
    clear_bash_history=True,
    clear_auth_logs=True,
    exfil_method="dns_chunks",
)


PROFILES = {
    "kiddie":    KIDDIE,
    "commodity": COMMODITY,
    "apt":       APT,
}


def get_profile(name: str) -> ActorProfile:
    if name not in PROFILES:
        raise ValueError(
            f"unknown actor profile {name!r}; choose one of "
            f"{', '.join(PROFILES)}"
        )
    return PROFILES[name]


def inter_step_pause(profile: ActorProfile) -> None:
    """Sleep between top-level steps to match the actor's pace."""
    if profile.inter_step_delay_max <= 0:
        return
    delay = random.uniform(profile.inter_step_delay_min, profile.inter_step_delay_max)
    if delay > 0:
        time.sleep(delay)
