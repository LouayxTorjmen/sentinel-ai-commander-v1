"""
act1_recon.py — Act 1: External Reconnaissance.

Tactic mapping (MITRE ATT&CK):
  T1595.001  Active Scanning :: Scanning IP Blocks
  T1590      Gather Victim Network Information
  T1592      Gather Victim Host Information
  T1589.002  Gather Victim Identity Information :: Email Addresses

This act assumes ONLY that the attacker has network reach to the DMZ subnet
(10.50.0.0/24). It does NOT assume any credentials, any prior knowledge of
hostnames, or any access beyond ICMP/TCP. Everything Act 1 produces feeds
Act 2's decision-making.

Detection expectations (defender side):
  T1595.001 → Suricata ET SCAN signatures, pfSense block correlation, Wazuh agent logs
  T1590     → Suricata DNS query signatures, BIND query logs, AXFR-refused logs
  T1592     → Suricata version-detect signatures, repeated TCP SYN bursts
  T1589.002 → Wazuh rule 4625 (Windows failed logon series), SMB null-session attempts
"""

from __future__ import annotations

import re
from pathlib import Path

from ..actor import ActorProfile, inter_step_pause
from ..menu import display_act_menu, prompt_yes_no, render_status_line
from ..runner import C, FailureDecision, Outcome, Runner, colour
from ..state import StateManager


ACT_NAME = "recon"

KNOWN_HOSTS = [
    ("10.50.0.10", "srv-ad-dns",   "Windows Server (AD + DNS)"),
    ("10.50.0.11", "srv-dns-bind", "Linux (BIND DNS)"),
    ("10.50.0.12", "srv-web",      "Linux (DVWA)"),
    ("10.50.0.13", "srv-sql",      "Linux (MySQL 8.4)"),
    ("10.50.0.14", "srv-ftp",      "Windows 10 (IIS FTP)"),
]

DMZ_RANGE = "10.50.0.0/24"


# ─── Menu definition ────────────────────────────────────────────────

ACT_OPTIONS = [
    ("1", "T1595.001  Scan IP block (nmap)              — find live hosts"),
    ("2", "T1590      DNS reconnaissance (dig + AXFR)   — DC + BIND probing"),
    ("3", "T1592      Service version detection (nmap)  — banner grab targets"),
    ("4", "T1589.002  User enumeration (rpcclient/ldap) — find AD usernames"),
]


# ─── Step 1: IP block scan ──────────────────────────────────────────

def step_scan_ip_block(runner: Runner, profile: ActorProfile, state: StateManager) -> bool:
    """T1595.001 — Active scanning of the DMZ /24 to identify live hosts.

    Uses ICMP echo + timestamp host discovery (`-PE -PP`) so that the
    scan does NOT waste time SYN-probing 250 nonexistent IPs in the /24.
    Real attackers would use -Pn to avoid ICMP fingerprinting; we make
    a deliberate trade-off documented in SUPERVISOR_GUIDE.
    """
    extra_flags = []
    if profile.nmap_max_rate > 0:
        extra_flags += ["--max-rate", str(profile.nmap_max_rate)]

    argv = [
        "nmap",
        profile.nmap_timing,
        "-sS",                          # SYN scan
        "-PE", "-PP",                   # ICMP echo + timestamp for host discovery
        "--top-ports", "100",
        "--open",
        "--host-timeout", "60s",
        *extra_flags,
        DMZ_RANGE,
    ]

    while True:
        result = runner.run(
            act=ACT_NAME, technique="T1595.001", tool="nmap",
            argv=argv, target_host=DMZ_RANGE, timeout=900,
            success_when_rc_in=(0, 1),
        )
        if result.outcome in (Outcome.SUCCESS, Outcome.PARTIAL):
            _ingest_nmap_output(state, runner.run_id, result.stdout)
            return True
        if result.decision == FailureDecision.RETRY:
            continue
        if result.decision == FailureDecision.SKIP:
            return False
        if result.decision == FailureDecision.QUIT:
            raise KeyboardInterrupt
        return False


def _ingest_nmap_output(state: StateManager, run_id: str, output: str) -> None:
    """Parse nmap text output, upsert hosts/services into state."""
    current_ip: str | None = None
    ports_for_ip: dict[str, list[int]] = {}
    services_for_ip: dict[str, dict[str, str]] = {}

    for raw_line in output.splitlines():
        line = raw_line.strip()
        m = re.match(r"^Nmap scan report for (?:([\w\-.]+) )?\(?([\d.]+)\)?$", line)
        if m:
            current_ip = m.group(2)
            ports_for_ip.setdefault(current_ip, [])
            services_for_ip.setdefault(current_ip, {})
            continue
        if current_ip:
            pm = re.match(r"^(\d+)/(\w+)\s+open\s+(\S+)", line)
            if pm:
                port = int(pm.group(1))
                svc = pm.group(3)
                ports_for_ip[current_ip].append(port)
                services_for_ip[current_ip][str(port)] = svc

    name_by_ip = {ip: name for ip, name, _ in KNOWN_HOSTS}
    for ip, ports in ports_for_ip.items():
        if not ports:
            continue
        state.upsert_host(
            run_id=run_id, ip=ip,
            hostname=name_by_ip.get(ip),
            open_ports=ports,
            services=services_for_ip.get(ip, {}),
            compromise_status="recon_only",
        )

    found = [(ip, len(p)) for ip, p in ports_for_ip.items() if p]
    if found:
        print(colour(f"\n  → ingested {len(found)} live hosts into state", C.GREEN))


# ─── Step 2: DNS recon (expanded) ──────────────────────────────────

# Common Active Directory SRV records — querying these is a textbook
# domain-reconnaissance pattern. Even if the DC is misconfigured and
# returns NXDOMAIN, the QUERIES themselves are detection-relevant.
AD_SRV_RECORDS = [
    "_ldap._tcp.dc._msdcs",
    "_kerberos._tcp.dc._msdcs",
    "_ldap._tcp",
    "_kerberos._tcp",
    "_kpasswd._tcp",
    "_gc._tcp",
    "_ldap._tcp.pdc._msdcs",
    "_ldap._tcp.gc._msdcs",
]

# Common subdomains an attacker would probe.
COMMON_SUBDOMAINS = [
    "www", "mail", "ftp", "vpn", "remote", "owa", "exchange",
    "intranet", "portal", "git", "jenkins", "wiki", "test", "dev",
    "staging", "backup", "admin", "ad", "dc", "dc01", "dc02",
    "sql", "db", "web", "fileserver",
]


def step_dns_recon(runner: Runner, profile: ActorProfile, state: StateManager) -> bool:
    """T1590 — DNS reconnaissance against both DNS servers in the DMZ.

    We probe TWO different DNS resolvers and TWO different domain names:
      - 10.50.0.10 (Windows AD DNS)   for mydomain.local SRV records
      - 10.50.0.11 (Linux BIND)        for both mydomain.local and any
                                       other zone that might be hosted

    The volume of queries is deliberately high. Sparse queries do not
    cross frequency-based detection thresholds; an attacker mapping a
    domain typically issues dozens of DNS queries. This makes the
    behaviour visible to defenders.
    """
    targets = [
        ("10.50.0.10", "AD DC"),
        ("10.50.0.11", "BIND"),
    ]
    zones = ["mydomain.local", "sentinel.lab"]

    # ── Phase A: SRV record probing against both resolvers ──
    print(colour("  ▎ phase A: SRV record probing", C.DIM))
    for resolver_ip, label in targets:
        for srv in AD_SRV_RECORDS[:4 if profile.name == "apt" else len(AD_SRV_RECORDS)]:
            qname = f"{srv}.mydomain.local"
            r = runner.run(
                act=ACT_NAME, technique="T1590", tool="dig",
                argv=["dig", f"@{resolver_ip}", qname, "SRV",
                      "+time=3", "+tries=1", "+short"],
                target_host=resolver_ip, timeout=10,
                success_when_rc_in=(0, 9, 10),    # 9 = no servers reachable (benign here)
            )
            if r.decision == FailureDecision.QUIT:
                raise KeyboardInterrupt
            inter_step_pause(profile)

    # ── Phase B: subdomain enumeration against both resolvers ──
    print(colour("  ▎ phase B: subdomain enumeration", C.DIM))
    subs = COMMON_SUBDOMAINS[:6 if profile.name == "apt" else len(COMMON_SUBDOMAINS)]
    for resolver_ip, label in targets:
        for sub in subs:
            for zone in zones:
                qname = f"{sub}.{zone}"
                r = runner.run(
                    act=ACT_NAME, technique="T1590", tool="dig",
                    argv=["dig", f"@{resolver_ip}", qname, "A",
                          "+time=3", "+tries=1", "+short"],
                    target_host=resolver_ip, timeout=10,
                    success_when_rc_in=(0, 9, 10),
                    show_command=False,            # too noisy to print 100 lines
                )
                if r.decision == FailureDecision.QUIT:
                    raise KeyboardInterrupt

    # ── Phase C: reverse DNS for the DMZ /24 ──
    print(colour("  ▎ phase C: reverse DNS sweep", C.DIM))
    for resolver_ip, _ in targets:
        for last_octet in [1, 10, 11, 12, 13, 14] + ([] if profile.name == "apt"
                                                     else list(range(20, 30))):
            ptr = f"{last_octet}.0.50.10.in-addr.arpa"
            r = runner.run(
                act=ACT_NAME, technique="T1590", tool="dig",
                argv=["dig", f"@{resolver_ip}", "-x", f"10.50.0.{last_octet}",
                      "+time=3", "+tries=1", "+short"],
                target_host=resolver_ip, timeout=10,
                success_when_rc_in=(0, 9, 10),
                show_command=False,
            )
            if r.decision == FailureDecision.QUIT:
                raise KeyboardInterrupt

    # ── Phase D: the actual attack — AXFR against both ──
    print(colour("  ▎ phase D: zone transfer attempts (AXFR)", C.DIM))
    for resolver_ip, _ in targets:
        for zone in zones:
            r = runner.run(
                act=ACT_NAME, technique="T1590", tool="dig",
                argv=["dig", f"@{resolver_ip}", zone, "AXFR",
                      "+time=5", "+tries=1"],
                target_host=resolver_ip, timeout=15,
                success_when_rc_in=(0, 9, 10),
            )
            if r.decision == FailureDecision.QUIT:
                raise KeyboardInterrupt

    return True


# ─── Step 3: Banner grab (fixed) ───────────────────────────────────

def step_banner_grab(runner: Runner, profile: ActorProfile, state: StateManager) -> bool:
    """T1592 — service version detection against recon'd hosts.

    Spreads each host IP as a separate argv element so nmap parses them
    correctly. (Earlier bug: passing a comma-joined string as one arg
    caused nmap to treat it as a hostname.)
    """
    hosts = state.hosts_for_run(runner.run_id)
    if not hosts:
        print(colour("  (!) no hosts recon'd yet — run step 1 first", C.YELLOW))
        return False

    extra_flags = []
    if profile.nmap_max_rate > 0:
        extra_flags += ["--max-rate", str(profile.nmap_max_rate)]

    target_ips = [h["ip"] for h in hosts]
    target_label = ",".join(target_ips)     # human-readable, only for the DB

    while True:
        result = runner.run(
            act=ACT_NAME, technique="T1592", tool="nmap",
            argv=[
                "nmap", profile.nmap_timing, "-sV", "-Pn",
                "--version-intensity", "5",
                "--host-timeout", "120s",
                *extra_flags,
                "-p", "21,22,53,80,135,139,389,443,445,464,636,1433,3268,3306,3389,5985,5986",
                *target_ips,
            ],
            target_host=target_label, timeout=900,
            success_when_rc_in=(0, 1),
        )
        if result.outcome in (Outcome.SUCCESS, Outcome.PARTIAL):
            _ingest_nmap_output(state, runner.run_id, result.stdout)
            return True
        if result.decision == FailureDecision.RETRY:
            continue
        if result.decision == FailureDecision.QUIT:
            raise KeyboardInterrupt
        return False


# ─── Step 4: User enumeration ──────────────────────────────────────

def step_user_enum(runner: Runner, profile: ActorProfile, state: StateManager) -> bool:
    """T1589.002 — enumerate AD users via multiple probes."""
    ad_ip = "10.50.0.10"

    # rpcclient null-session enumdomusers
    while True:
        r1 = runner.run(
            act=ACT_NAME, technique="T1589.002", tool="rpcclient",
            argv=["bash", "-c",
                  f"rpcclient -U '' -N {ad_ip} -c 'enumdomusers' 2>&1"],
            target_host=ad_ip, timeout=30,
            success_when_rc_in=(0, 1),
        )
        if r1.decision == FailureDecision.QUIT:
            raise KeyboardInterrupt
        if r1.outcome != Outcome.FAILURE or r1.decision != FailureDecision.RETRY:
            break
    inter_step_pause(profile)

    # Anonymous LDAP bind + search
    while True:
        r2 = runner.run(
            act=ACT_NAME, technique="T1589.002", tool="ldapsearch",
            argv=[
                "ldapsearch", "-x",
                "-H", f"ldap://{ad_ip}",
                "-b", "DC=mydomain,DC=local",
                "(objectClass=user)",
                "sAMAccountName",
            ],
            target_host=ad_ip, timeout=30,
            success_when_rc_in=(0, 1, 50),
        )
        if r2.decision == FailureDecision.QUIT:
            raise KeyboardInterrupt
        if r2.outcome != Outcome.FAILURE or r2.decision != FailureDecision.RETRY:
            break
    inter_step_pause(profile)

    # impacket-lookupsid (RID cycling) — force null session with -no-pass
    # Use `domain/anonymous:@host` (note the colon and empty password) so
    # impacket doesn't prompt interactively. -no-pass tells it not to ask.
    while True:
        r3 = runner.run(
            act=ACT_NAME, technique="T1589.002", tool="impacket-lookupsid",
            argv=["bash", "-c",
                  f"impacket-lookupsid -no-pass 'mydomain.local/anonymous:@{ad_ip}' 2>&1 || true"],
            target_host=ad_ip, timeout=60,
            success_when_rc_in=(0, 1),
        )
        if r3.decision == FailureDecision.QUIT:
            raise KeyboardInterrupt
        if r3.outcome != Outcome.FAILURE or r3.decision != FailureDecision.RETRY:
            break

    return True


# ─── Dispatcher / 'Run ALL' ─────────────────────────────────────────

STEPS = {
    "1": ("Scan IP block",      step_scan_ip_block),
    "2": ("DNS recon",          step_dns_recon),
    "3": ("Banner grab",        step_banner_grab),
    "4": ("User enumeration",   step_user_enum),
}


def run_one(key: str, runner: Runner, profile: ActorProfile, state: StateManager) -> bool:
    label, fn = STEPS[key]
    print(colour(f"\n──── Act 1 :: {label} ────", C.MAGENTA, C.BOLD))
    return fn(runner, profile, state)


def run_all(runner: Runner, profile: ActorProfile, state: StateManager) -> None:
    for k in sorted(STEPS):
        try:
            run_one(k, runner, profile, state)
        except KeyboardInterrupt:
            print(colour("\n  (Ctrl+C in Act 1 — returning to main menu)", C.YELLOW))
            return
        inter_step_pause(profile)


def loop(runner: Runner, profile: ActorProfile, state: StateManager) -> None:
    while True:
        render_status_line(state, runner.run_id)
        choice = display_act_menu("Act 1 :: External Reconnaissance", ACT_OPTIONS)
        if choice == "b":
            return
        if choice == "a":
            run_all(runner, profile, state)
            if prompt_yes_no("Continue to Act 2?", default=True):
                return
            continue
        try:
            run_one(choice, runner, profile, state)
        except KeyboardInterrupt:
            print(colour("\n  (interrupted — back to act menu)", C.YELLOW))
