"""
menu.py — Operator UI. Banners, main menu, act sub-menus, state inspector.

Two paradigms combined per design Decision 2 (A+C):

  A — menu-driven  : numbered options at every junction
  C — linear story : 'run all' inside an act marches through phases
                     in order, prompting "continue to next act?" between.

Everything here is pure presentation. Logic lives in the act modules.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from .actor import ActorProfile
from .runner import C, colour
from .state import StateManager


BANNER = r"""
   ███████╗███████╗███╗   ██╗████████╗██╗███╗   ██╗███████╗██╗
   ██╔════╝██╔════╝████╗  ██║╚══██╔══╝██║████╗  ██║██╔════╝██║
   ███████╗█████╗  ██╔██╗ ██║   ██║   ██║██╔██╗ ██║█████╗  ██║
   ╚════██║██╔══╝  ██║╚██╗██║   ██║   ██║██║╚██╗██║██╔══╝  ██║
   ███████║███████╗██║ ╚████║   ██║   ██║██║ ╚████║███████╗███████╗
   ╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝

           S E N T I N E L   A T T A C K   O R C H E S T R A T O R
"""


def render_banner(profile: ActorProfile, run_id: str) -> None:
    print(colour(BANNER, C.MAGENTA, C.BOLD))
    print(colour(f"  actor: {profile.name:<10}", C.CYAN, C.BOLD) +
          colour(f"   run: {run_id}", C.DIM))
    print(colour(f"  profile: {profile.description}", C.DIM))
    print()


def render_status_line(state: StateManager, run_id: str) -> None:
    """One-liner kept above each menu so operator always sees the score."""
    s = state.summary(run_id)
    parts = [
        f"hosts seen: {s['hosts_recon']}",
        f"pwned: {s['hosts_compromised']}",
        f"creds: {s['credentials']} ({s['creds_verified']} verified)",
        f"loot: {s['artifacts']}",
    ]
    print(colour("  ▎ " + "   ".join(parts), C.BLUE, C.BOLD))


# ─── Generic menu primitive ─────────────────────────────────────────

def prompt_menu(title: str, options: list[tuple[str, str]]) -> str:
    """
    options: list of (key, label).
    Returns the chosen key (lowercased).
    Loops on invalid input.
    """
    print()
    print(colour(f"  ═══ {title} ═══", C.CYAN, C.BOLD))
    for key, label in options:
        print(colour(f"    [{key}] ", C.GREEN, C.BOLD) + label)
    print()
    valid = {k.lower() for k, _ in options}
    while True:
        try:
            choice = input(colour("  > ", C.BOLD)).strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return "q"
        if choice in valid:
            return choice
        print(colour("    invalid choice — try one of: " + ", ".join(valid),
                     C.RED))


def prompt_yes_no(question: str, default: bool = True) -> bool:
    suffix = " [Y/n] " if default else " [y/N] "
    while True:
        try:
            ans = input(colour("  " + question + suffix, C.YELLOW)).strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return False
        if ans == "":
            return default
        if ans in ("y", "yes"):
            return True
        if ans in ("n", "no"):
            return False


# ─── Main menu ──────────────────────────────────────────────────────

MAIN_MENU = [
    ("1", "Act 1 — External Reconnaissance"),
    ("2", "Act 2 — Initial Access (requires Act 1 data)"),
    ("3", "Act 3 — Post-Exploitation (requires Act 2 foothold)"),
    ("s", "Show scenario state"),
    ("e", "Export evidence (timestamps for Wazuh correlation)"),
    ("q", "Quit"),
]


# ─── Act sub-menus declared by the act modules ──────────────────────
# Each act module passes its menu to display_act_menu().

def display_act_menu(
    act_title: str,
    options: list[tuple[str, str]],
) -> str:
    full = list(options) + [
        ("a", "Run ALL of this act sequentially"),
        ("b", "Back to main menu"),
    ]
    return prompt_menu(act_title, full)


# ─── State display ──────────────────────────────────────────────────

def show_state(state: StateManager, run_id: str) -> None:
    s = state.summary(run_id)
    print()
    print(colour("═══════════════════════════════════════════════════════════════", C.CYAN))
    print(colour("  SCENARIO STATE", C.CYAN, C.BOLD))
    print(colour("═══════════════════════════════════════════════════════════════", C.CYAN))

    print()
    print(colour("  Step outcomes:", C.BOLD))
    for outcome, n in s["step_outcomes"].items():
        sym = {"success": "✓", "failure": "✗", "skipped": "·", "partial": "~",
               "running": "↻"}.get(outcome, "?")
        clr = {"success": C.GREEN, "failure": C.RED, "skipped": C.DIM,
               "partial": C.YELLOW, "running": C.CYAN}.get(outcome, C.RESET)
        print(colour(f"    {sym} {outcome:<9} {n:>4}", clr))

    print()
    print(colour("  Hosts:", C.BOLD))
    hosts = state.hosts_for_run(run_id)
    if not hosts:
        print(colour("    (none recon'd yet)", C.DIM))
    else:
        for h in hosts:
            status_clr = {"unknown": C.DIM, "recon_only": C.YELLOW,
                          "partial": C.YELLOW, "pwned": C.RED}.get(
                              h["compromise_status"], C.RESET)
            ports = h["open_ports"] or "[]"
            print(colour(
                f"    {h['ip']:<15} {h['hostname'] or '?':<18} "
                f"{h['compromise_status']:<12} ports={ports}",
                status_clr))

    print()
    print(colour("  Credentials:", C.BOLD))
    creds = state.credentials_for_run(run_id)
    if not creds:
        print(colour("    (none discovered yet)", C.DIM))
    else:
        for c in creds:
            vsym = {1: colour("✓", C.GREEN), 0: colour("?", C.YELLOW),
                    -1: colour("✗", C.RED)}.get(c["verified"], "?")
            pw = c["password"] if c["password"] else colour("(hash only)", C.DIM)
            print(f"    {vsym} {c['source']:<14} {c['system'] or '?':<14} "
                  f"{c['username']:<25} {pw}")

    print()
    print(colour("  Artifacts:", C.BOLD))
    artifacts = state.artifacts_for_run(run_id)
    if not artifacts:
        print(colour("    (no loot collected yet)", C.DIM))
    else:
        for a in artifacts:
            print(f"    {a['artifact_type']:<14} {a['source_host']:<14} "
                  f"{a['description']} ({a['size_bytes']} B)")

    print()


# ─── Evidence export ────────────────────────────────────────────────

def export_evidence(state: StateManager, run_id: str, out_dir: Path) -> Path:
    """
    Dump the run's state to a structured JSON file the defender can
    correlate against Wazuh's alerts index.

    Output: out_dir/evidence_<run_id>.json
    """
    payload = state.export_evidence(run_id)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"evidence_{run_id}.json"
    out_path.write_text(json.dumps(payload, indent=2, default=str))
    print(colour(f"  ✓ evidence written to {out_path}", C.GREEN, C.BOLD))
    print(colour(
        f"    (steps={len(payload['steps'])}, hosts={len(payload['hosts'])}, "
        f"creds={len(payload['credentials'])}, artifacts={len(payload['artifacts'])})",
        C.DIM))
    return out_path
