# SENTINEL-AI :: Attack Scenario Orchestrator
## Supervisor Documentation

---

**Project:** SENTINEL-AI Commander v2
**Component:** `~/sentinel-attack/` — adversary emulation orchestrator
**Author:** Louay Torjmen
**Repository:** `LouayxTorjmen/sentinel-ai-commander-v1`

---

## 1. Purpose of this document

This document explains what the attack scenario orchestrator is, why it was built the way it was, and how it serves the broader goal of the SENTINEL-AI Commander project. It is written for a reader who knows the security domain at a conceptual level but does not need to be a developer to follow along. Where a technical concept might be unfamiliar to a non-specialist (Active Directory Kerberos roasting, SQL injection mechanics, etc.) a *Sidebar* paragraph unpacks it briefly.

## 2. Where this fits in the bigger picture

The SENTINEL-AI Commander project has two halves that meet in the middle. The **defender side** runs Wazuh, Suricata, and a chain of AI agents on a single Docker host (`sentinel-ai-commander`). The **adversary side** runs from a Kali Linux virtual machine and simulates real attacker behavior against the seeded victim hosts.

These two halves were built independently for a reason. A defender's effectiveness can only be measured against real adversary behavior — not against synthetic test alerts, and not against textbook descriptions of techniques. By writing a controllable, repeatable adversary that produces the same network and host telemetry a real attacker would, the project can demonstrate end-to-end value: "an attacker did X, Wazuh saw it, the AI agent reasoned about it, and Ansible responded." Without a credible adversary, the AI agent's reasoning has nothing to chew on.

> **Sidebar — "adversary emulation"**
> Adversary emulation means running real attack tools against real (or, here, simulated) victims, with the intent of generating *defender-side* telemetry. It is not penetration testing — the goal is not to find vulnerabilities but to exercise detection. The most well-known emulation framework is MITRE's Caldera. Our orchestrator fulfills the same role but is custom-built for repeatability with the seeded lab.

## 3. Goals the orchestrator must meet

When designing this component we set five non-negotiable goals:

1. **Reproducibility.** Two runs with the same actor profile must produce essentially the same telemetry on the defender side. This rules out random tool choices and uncontrolled timing.
2. **Auditability.** Every command the orchestrator runs must be logged with a timestamp, exit code, and full output, so that any alert seen by Wazuh can be traced back to the attacker action that caused it.
3. **MITRE alignment.** Every step must map cleanly to a published ATT&CK technique. The thesis evidence chapter is much easier to write when the attacker actions can be cited by technique ID rather than described from scratch.
4. **Three adversary tiers.** A single attack chain must be executable at three different levels of stealth and sophistication, so we can demonstrate that detection holds (or fails) against patient adversaries as well as loud ones.
5. **Defensible thesis story.** Every shortcut taken for repeatability (e.g. using a targeted wordlist instead of rockyou.txt) must be explainable in the supervisor defense as a deliberate methodology choice, not a hidden compromise.

## 4. Architectural decisions and the reasoning behind them

This section walks through every meaningful design decision and explains why each alternative was rejected. The supervisor presentation should be able to draw on this directly.

### 4.1 Why MITRE ATT&CK and not the Lockheed Martin kill chain

Both frameworks describe adversary behavior, but they operate at different granularities. The Lockheed kill chain (Reconnaissance → Weaponization → Delivery → Exploitation → Installation → C2 → Actions on Objectives) is a process model. ATT&CK is a *technique catalog*. For the purpose of mapping individual commands to defender alerts, the technique catalog is dramatically more useful — Suricata signatures often cite ATT&CK technique IDs directly, and Wazuh's rule descriptions increasingly do the same.

The kill chain still informs the overall narrative structure of the scenario (Acts 1–3 roughly map to reconnaissance → access → actions on objectives), but the operational unit of measurement is the ATT&CK technique.

### 4.2 Why direct attack tools and not a C2 framework

The original plan called for Sliver, a modern open-source command-and-control framework comparable to Cobalt Strike. After installation and evaluation on Kali we found that the version shipping in Kali's repository exposes only 11 file-system operations through its Model Context Protocol (MCP) interface — not enough to drive the full intrusion narrative from a Python script. Driving Sliver via its interactive shell was possible but would require parsing terminal output from a REPL, which is brittle, and using its gRPC operator API would require generating operator certificates and writing protocol-buffer glue code that adds no thesis value.

We chose instead to drive direct attack tools — `nmap`, `sqlmap`, `hydra`, `impacket-*`, `john`, `ssh`, `curl` — from a Python orchestrator. The supervisor-facing defense of this choice rests on a simple observation: **the defender sees commands, not the C2 channel that delivered them**. A SQL injection request looks identical to Suricata whether it was issued by Sliver's HTTP module or by a raw `curl` invocation. A kerberoasting attempt produces the same network signature regardless of which framework requested the service ticket. By using the underlying tools directly we obtain telemetry equivalent to what a real attacker (using Sliver or Cobalt Strike) would produce, while eliminating a fragile dependency.

> **Sidebar — "C2 framework"**
> Command and Control (C2) frameworks are the tools attackers use after gaining initial access. They provide an encrypted channel back to the attacker's machine and a set of post-exploitation modules (credential dumping, lateral movement, persistence). Sliver and Cobalt Strike are the two most prominent in 2026. A defender's job is partly to detect that a C2 channel exists, but most defender alerts fire on the *actions* a C2 channel carries — file reads, process creations, network connections to internal hosts. Those actions look the same regardless of the framework wrapping them.

### 4.3 Why three actor profiles

A single attack chain run at a single speed is not interesting from a detection-evaluation perspective. Defenders want to know whether their tooling catches the patient adversary as well as the noisy one. We defined three profiles:

- **`kiddie`** — fastest, loudest, no operational security. Every default tool flag is used as-is. Brute force runs at sixteen threads. No cleanup is performed after exploitation. This profile maximizes the number of Wazuh and Suricata alerts and serves as a sanity check on baseline detection.
- **`commodity`** — a mid-tier actor running known offensive tooling with some basic operational security: spoofed browser user-agent, modest rate-limiting, post-exploit bash-history clearing. This profile tests detection against the largest category of real attackers.
- **`apt`** — patient adversary modeling. Scans use `nmap -T1` with explicit rate caps. Brute force runs single-threaded with three-second pauses. Random fifteen-to-sixty-second pauses between top-level steps. Legitimate-looking HTTP headers. Bash history and auth logs cleared after exploitation. This profile tests whether detection holds when an attacker is deliberately slow.

The profile is selected at launch time via a `--actor` flag and applied uniformly throughout the scenario. Each tool invocation reads its timing, concurrency, and user-agent settings from the active profile.

### 4.4 Why SQLite for state

The orchestrator must remember things across steps and across runs. Phase 1 discovers open ports — Phase 2 needs to know which hosts to attack. Phase 2 dumps credentials — Phase 3 needs to try them against discovered hosts. This is fundamentally relational reasoning ("for every credential whose service is SSH, try it against every host whose port 22 is open"), and SQLite is the right tool for it.

We considered two alternatives. A flat JSON file would have been simpler to read but would force Python list-comprehension filtering everywhere the orchestrator queries state — code is harder to read, and the data is harder for a defender to query later. An in-memory dictionary would have been the simplest of all but would lose state between runs and prevent the operator from resuming an interrupted scenario.

The SQLite schema includes a lookup table of MITRE techniques seeded once at first run. Every step inserted into the `steps` table is tagged with a technique ID that joins to that lookup, so a future query like "give me every step in Act 2 tagged with a Credential Access tactic" becomes a single SQL statement.

### 4.5 Why a menu-driven interface and not a REPL

The operator interface had three plausible designs: a numbered menu, a REPL where the operator types commands like `recon srv-web`, or a fully scripted linear flow with continue-prompts between phases. We chose to combine the menu with the linear flow.

The numbered menu reduces cognitive load for the supervisor demo. The operator never has to remember a command name; everything visible is one keystroke away. The linear "run all in this act" option satisfies the operator who wants to march through the scenario without picking individual steps. A REPL would have been the most "attacker-like" experience but would have tripled the implementation effort for a marginal gain in realism, since the orchestrator is not itself the adversary tradecraft — the underlying tools are.

### 4.6 Why interactive failure handling

When a step fails (the DVWA exploit returns a 500, hydra finds no working password, an SSH connection refused), the orchestrator stops and prompts the operator with five options: retry, skip, back to act menu, inspect the log file, or quit the scenario. This is more user effort than a hard-stop-on-failure design, but the trade-off is worth it for two reasons.

First, the seeded lab is occasionally flaky in ways that have nothing to do with the scenario — a Windows host might be paged out, a Docker network briefly hiccups, the BIND DNS server might be reloading. A retry recovers from these without restarting the whole run. Second, failures themselves are detection-relevant — a failed exploit attempt still generates Wazuh alerts and Suricata signatures — so the operator should be able to acknowledge the failure and continue producing evidence.

### 4.7 Why we generate a "targeted" wordlist, and why john instead of hashcat

This decision deserves the most careful explanation because it is the area where the orchestrator most visibly diverges from a real-world attack.

In a real intrusion, an attacker who has obtained AS-REP roasted hashes or kerberoasted SPN tickets cracks them offline against a large dictionary, most commonly `rockyou.txt` (14 million leaked passwords), using a GPU-accelerated tool like `hashcat`. Cracking can take minutes if the password is in the dictionary; hours or days if it is not. Whether the attacker recovers a plaintext password is a probabilistic outcome that depends on the password's strength, the cracking machine's hardware, and the wordlist used.

For a thesis demonstration we need the cracking step to *always succeed*, otherwise the rest of the scenario (using the cracked password for lateral movement) cannot run. Three options were considered:

1. Use `rockyou.txt` with `hashcat` and hope the seeded password is in it. The seeded passwords (`Summer2024!`, `Welcome2024!`) are deliberately chosen to *not* be in rockyou — they follow a pattern that resembles real corporate passwords. So this option fails by design.
2. Skip the cracking step and pretend the password was recovered. This loses the actual cracking invocation, which is a detection-relevant action (it leaves a process-execution event in the auditd log).
3. Generate a small, targeted wordlist that *contains* the seeded password plus a large number of plausible season-year patterns. This option preserves every aspect of the cracking event the defender would observe — same process name, same CPU spike, same output file format — while guaranteeing the cracking succeeds.

We chose option 3. The wordlist is generated by `wordlists/gen_wordlist.py` and contains approximately 750 entries built from {Spring/Summer/Autumn/Winter} × {2020–2027} × seven common suffixes, plus the seeded passwords themselves and a handful of common bases.

A secondary practical decision: we use `john` (CPU-only) rather than `hashcat` (GPU-accelerated). `hashcat` requires more memory than a small Kali VM (2 GB RAM) can typically allocate, and fails with "Not enough allocatable device memory or free host memory for mapping" on undersized lab hardware. `john` runs entirely on the CPU and has no equivalent memory requirement, so the scenario is reproducible on resource-constrained lab hardware. The trade-off is speed: hashcat against a GPU is roughly 100× faster, but against a 750-entry targeted wordlist both tools complete in under one second, so the speed difference is irrelevant for this scenario.

The supervisor defense of these choices is straightforward: the *network behavior* is fully real (Kerberos AS-REP and TGS-REP traffic, no shortcut taken), and the cracking is real (`john` actually runs against the actually-roasted hash); only the dictionary is curated and the tool is CPU-based. A real attacker would simply use a longer dictionary and a GPU. The defender-side signatures are identical.

> **Sidebar — "AS-REP roasting" and "kerberoasting"**
> Two Active Directory attacks that recover passwords without ever asking the Domain Controller to validate them.
>
> *AS-REP roasting* works against accounts that have the `DoesNotRequirePreAuth` flag set. Normally Kerberos requires the user to encrypt a timestamp with their password as proof-of-knowledge before the DC will issue a ticket. Accounts with the flag set skip that step, so anyone on the network can request an AS-REP for them. The AS-REP is encrypted with the user's password, so an attacker can crack it offline.
>
> *Kerberoasting* works against any account with a registered Service Principal Name (SPN). When any authenticated user requests a service ticket for that SPN, the ticket is encrypted with the service account's password hash. The requester can then crack the ticket offline.
>
> Both attacks are detection-friendly: the request looks slightly anomalous in the DC's event log (event ID 4769), and Suricata has Kerberos protocol signatures. The seeded lab contains one account vulnerable to each attack.

## 5. The three acts in detail

This section maps each act to the MITRE techniques it covers and the tools it uses.

### Act 1 — External Reconnaissance

Assumes only network reach to the DMZ subnet (10.50.0.0/24). Produces a populated hosts table that Acts 2 and 3 build on.

| Step | Technique  | Tool          | What it does                                              |
|------|------------|---------------|-----------------------------------------------------------|
| 1    | T1595.001  | nmap          | Discovers live hosts and quick-scan top 100 ports         |
| 2    | T1590      | dig           | Queries srv-dns-bind, attempts zone transfer (AXFR)       |
| 3    | T1592      | nmap -sV      | Service version and banner detection across found ports   |
| 4    | T1589.002  | rpcclient, ldapsearch, impacket-lookupsid | Anonymous AD user enumeration |

Expected defender signals: Suricata SCAN rules, BIND query log entries for the refused AXFR, Windows event 4625 series for the rpcclient null-session attempt.

### Act 2 — Initial Access

| Step | Technique  | Tool          | What it does                                              |
|------|------------|---------------|-----------------------------------------------------------|
| 1    | T1190      | curl          | Authenticates to DVWA, drops a PHP webshell via the Command Injection page |
| 2    | T1110.001  | hydra         | Targeted FTP brute force against srv-ftp                  |
| 3    | T1078      | sqlmap        | Uses the DVWA session to dump the seeded `infra_credentials` table via SQLi |

The webshell from step 1 is a four-line PHP script that takes `?cmd=` and shells out via `system()`. It is intentionally trivial and triggers every standard PHP webshell signature. The webshell URL is recorded as an artifact so Act 3 can reach back to it.

### Act 3 — Post-Exploitation

| Step | Technique  | Tool                   | What it does                                              |
|------|------------|------------------------|-----------------------------------------------------------|
| 1    | T1003.008  | webshell + cat         | Attempts to read /etc/shadow (usually denied, but logged) |
| 2    | T1083      | webshell + find        | Filesystem enumeration                                    |
| 3    | T1558.004  | impacket-GetNPUsers    | AS-REP roast against svc-legacy                           |
| 4    | T1558.003  | impacket-GetUserSPNs   | Kerberoast against svc-mssql                              |
| 5    | T1110.002  | john                   | Cracks the roasted hashes using the targeted wordlist     |
| 6    | T1021.004  | ssh + sshpass          | Lateral movement using every verified SSH credential      |
| 7    | T1041      | tar + nc               | Bundles artifacts and exfiltrates to a Kali listener      |
| 8    | T1486      | webshell + bash here-doc | Drops a SYMBOLIC ransom note. **No files are encrypted.** |

The symbolic-impact choice in step 8 is intentional. A real ransomware payload would render the lab unusable for replay. We instead drop a marker file that Wazuh's File Integrity Monitoring sees as a new file in `/tmp/`, generating an event whose detection is identical (`syscheck` rule 554 for "file added") whether the file is a ransom note or a real encrypted payload.

## 6. State, evidence, and audit trail

Every step the orchestrator runs creates a row in the SQLite `steps` table with five fields that matter for evidence: the MITRE technique ID, the tool name, the target host, the start and end timestamps, and the exit code. The full standard output of the command is written to a separate log file under `~/scenario_runs/<run_id>/`.

This separation matters. The database is small enough to query quickly even after dozens of runs; the log files are large but accessed only when the operator wants to inspect a specific step. The evidence export (main menu option `e`) writes a structured JSON file combining both, with passwords redacted, suitable for handing to the AI agent's correlation logic.

## 7. How the operator runs a scenario end-to-end

A complete supervisor demo proceeds as follows.

1. On the WSL2 host, ensure the lab is seeded: `./scripts/seed_scenario.sh`. This is a one-time setup that creates the `infra_credentials` table and the weak AD service accounts.
2. On Kali, install required tools: `python3 ~/sentinel-attack/scenario.py --check-tools` and install anything missing.
3. (Optional) Generate the targeted wordlist explicitly: `python3 ~/sentinel-attack/wordlists/gen_wordlist.py`.
4. (Optional, for step 7 only) Start the exfiltration listener in a separate Kali terminal: `nc -lvp 9999 > /tmp/exfil_bundle.tar.gz`.
5. Start the scenario: `sudo python3 ~/sentinel-attack/scenario.py --actor apt`.
6. From the main menu choose Act 1. Inside the act sub-menu either run individual steps or pick "Run ALL" to march through. Repeat for Acts 2 and 3.
7. After completion, return to the main menu and pick `e` to export evidence. The result is a JSON file at `~/scenario_runs/evidence_<run_id>.json`.

## 8. Correlating attacker evidence with defender alerts

The orchestrator records timestamps with second precision in UTC. On the defender side, Wazuh stores its alerts with the same precision in the same timezone. Correlation is a join on time-windows: for every step row with start and end timestamps, query the Wazuh alerts index for any alert in that window with the same source IP or hostname.

This join is not implemented inside the orchestrator because the orchestrator runs on Kali, which by design has no privileged access to the Wazuh dashboard. The correlation step is a separate utility (`correlate.py`) that runs on the WSL2 host and consumes the evidence export from the Kali side. That separation reflects the project's overall design: the attacker side and the defender side communicate only through the artifacts each produces.

## 9. Honest limitations

A complete thesis defense must include the limitations. These are the ones a reviewer is most likely to ask about:

- **Targeted wordlist with `john` instead of `hashcat`.** Discussed at length in section 4.7. The cracking step is real but its dictionary is curated, and the tool is CPU-based rather than GPU-accelerated to accommodate small lab VMs.
- **Symbolic impact.** The ransomware step (T1486) does not encrypt files. Detection of the event is identical to a real encryption operation, but the lab is preserved.
- **No initial access vector "from the internet."** The lab is internal. We assume the attacker already has network reach to the DMZ. A complete real-world emulation would include a phishing or supply-chain step that delivered that reach.
- **Single-victim webshell.** Act 2 establishes a foothold only on srv-web. The lab has no second compromised host until Act 3's lateral SSH step. A more elaborate scenario would pivot through srv-web to attack hosts unreachable from the attacker network directly.
- **No defender response in the loop.** The orchestrator runs to completion regardless of what the defender side does. A more realistic exercise would have the AI Commander actively trying to disrupt the attacker mid-scenario; that is on the project's roadmap but out of scope for this iteration.

## 10. Glossary

| Term            | Plain-English meaning                                                                                                |
|-----------------|----------------------------------------------------------------------------------------------------------------------|
| MITRE ATT&CK    | A public catalog of techniques attackers use. Each technique has an ID like T1190.                                   |
| Tactic          | The "why" behind a technique. The tactics in this scenario are Recon, Initial Access, Credential Access, Discovery, Lateral Movement, Exfiltration, and Impact. |
| Technique       | The "how." T1190 = exploit a public-facing application. T1558.003 = kerberoasting. Etc.                              |
| Adversary emulation | Running real attack tools to test defender detection. Different from penetration testing, which finds vulnerabilities. |
| Webshell        | A small script (PHP, JSP, etc.) placed on a compromised web server that lets the attacker run commands by visiting a URL. |
| Brute force     | Trying many usernames/passwords against a service until one works.                                                   |
| Credential dumping | Reading password hashes from a compromised system, usually from /etc/shadow on Linux or LSASS memory on Windows. |
| Kerberoasting   | An AD attack that recovers service-account passwords by requesting and cracking service tickets.                     |
| AS-REP roasting | An AD attack against accounts with weak preauthentication settings; recovers any password.                           |
| Lateral movement | Moving from one compromised host to another within a network.                                                       |
| Exfiltration    | Transmitting stolen data out of the victim network to the attacker.                                                  |
| C2              | Command and control — the channel an attacker uses to operate compromised hosts.                                     |
| MITRE Caldera   | A specific adversary-emulation framework; mentioned for context. We do not use it.                                   |
| Sliver          | A modern open-source C2 framework. Evaluated and rejected for this iteration — see section 4.2.                      |
| Wazuh           | The defender-side SIEM in our project; sees host events.                                                             |
| Suricata        | The defender-side network IDS; sees packets.                                                                          |

---

*End of document.*
