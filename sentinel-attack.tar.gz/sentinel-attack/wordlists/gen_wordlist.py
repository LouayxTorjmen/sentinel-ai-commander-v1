#!/usr/bin/env python3
"""
gen_wordlist.py — Generate the targeted hashcat wordlist offline.

Run this once after cloning the repo:

    python3 wordlists/gen_wordlist.py

Writes to wordlists/targeted.txt. The Act 3 cracking step calls this
generator automatically if the file is missing, but it's cleaner to
have it as a separate artifact for the supervisor to inspect.

See docs/SUPERVISOR_GUIDE.md for the honest framing of why we use a
targeted wordlist instead of rockyou.txt.
"""

import sys
from pathlib import Path

# Make repo importable
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))

from lib.acts.act3_postex import _inline_targeted_wordlist  # noqa: E402


def main() -> None:
    out_path = HERE / "targeted.txt"
    content = _inline_targeted_wordlist()
    out_path.write_text(content)
    n_lines = len(content.strip().splitlines())
    print(f"wrote {n_lines} candidate passwords to {out_path}")


if __name__ == "__main__":
    main()
